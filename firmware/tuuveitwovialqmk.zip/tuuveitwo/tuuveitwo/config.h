
#pragma once
#define VENDOR_ID 0x1234
#define PRODUCT_ID 0x5678
#define MANUFACTURER "Santeridahlia"
#define DEVICE_VER 0x0100
#define PRODUCT "tuuveitwo"


#define NO_ACTION_TAPPING


#define MATRIX_ROWS 12
#define MATRIX_COLS 10
#define ENCODERS_PAD_A {F4}
#define ENCODERS_PAD_B {F5}
#define ENCODERS_RESOLUTIONS 4




#define MATRIX_ROW_PINS { B6, B5, B3, B1, F7, F6}
#define MATRIX_COL_PINS { B2, E6, B4, D7, D2, C6, D4}


#define DIODE_DIRECTION ROW2COL
#define USE_I2C
#define MATRIX_ROW_PINS_RIGHT { B6, B2, B3, B1, F7, F5 }
#define MATRIX_COL_PINS_RIGHT { B5, B4, F6, D7, C6, D4, D2, D3, F4, E6 }

#define DEBOUNCE 5
#define F_SCL 100000L
